//jQueryで実行する内容
$(document).ready(function () {
  $(".slider").slick({
    dots: true, // ドット（インジケーター）を表示
    arrows: true, // 左右の矢印を表示
    infinite: false, // 無限ループ
    speed: 300, // スライド速度（ミリ秒）
    slidesToShow: 1, // 一度に表示するスライド数
    slidesToScroll: 1, // 一度にスクロールするスライド数
    autoplay: false, // 自動再生（必要に応じてtrueに）
    autoplaySpeed: 3000, // 自動再生の間隔
  });
});

